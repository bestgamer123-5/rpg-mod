package com.example.rpgminecraft;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1834;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RpgMinecraftMod implements ModInitializer {

    public static final String MOD_ID = "rpgminecraft";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final class_1792 RPG_SWORD = class_2378.method_10230(
            class_7923.field_41178,
            class_2960.method_43902(MOD_ID, "rpg_sword"),
            new class_1829(
                    class_1834.field_8930,
                    6,
                    -2.2f,
                    new class_1792.class_1793()
            )
    );

    @Override
    public void onInitialize() {

        LOGGER.info("RPG Minecraft loaded!");
    }

    public static void awardExperience(
            class_1657 player,
            class_1309 defeatedEntity
    ) {

        class_1799 mainHand = player.method_6047();

        if (!mainHand.method_31574(RPG_SWORD)) {
            return;
        }

        int bonusXp = defeatedEntity.method_6063() >= 20 ? 4 : 2;

        player.method_7255(bonusXp);

        LOGGER.info(
                "Granted {} bonus XP to {}",
                bonusXp,
                player.method_5477().getString()
        );
    }
}